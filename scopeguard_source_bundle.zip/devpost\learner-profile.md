---
doc: learner-profile
---

# Learner Profile

## Initial Idea
ScopeGuard: An AI Collateral-Damage Firewall & Surgical Code Splicer. It solves the exact pain of developers asking AI for a simple feature or UI tweak, only for the AI to silently modify unrelated functions, delete safety guards, or break existing CSS layouts. ScopeGuard performs AST diff analysis between User Intent and AI Output, renders an Apple-Pro Concordance Ring & Silent Regression Radar, and provides a 1-click Surgical Splicer to purge unauthorized collateral damage while keeping the requested feature.

## Demonstrated Technical and Agent Experience
Experienced developer who has personally faced AI collateral regressions ("previously when i was using ai, i would ask for a simple addition... but the ai would add something else somewhere unnecessarily or change something... and i would realise this only after many days"). Demands real computer science foundation, deterministic static analysis, and zero fake mockups.

## Planning-Workflow Experience
Committed to plan-first, spec-driven development using the official Devpost Learn curriculum.

## Desired Learning Outcome
Master how to build deterministic AST diff parsing, unified hunk classification, and surgical patch reconstruction in TypeScript, packaged in an Apple-grade calm workbench.

## Interests, Inspirations, and Goals
- Apple Pro Instruments & Activity Rings aesthetic: calm typography, high contrast, zero arcade gimmicks, extreme clarity.
- Goal: Create an authentic, undeniably useful developer tool with a killer 90-second video demo that wins the Devpost Build With AI Basics podium ($1,250 1st place).

## Vocabulary and Concepts Likely to Need Explanation
AST (Abstract Syntax Tree) symbol extraction, Myers diff algorithm, unified hunk splicing, and Devpost artifact contracts.

## Collaboration and Communication Preferences
Sharp, strategic, engineering-driven collaboration. Validate real functionality at every step.

## Areas Where the Learner Wants Ownership
Product direction, UX clarity, real-world bug scenarios, and final submission.

## Likely Support Needs
Full TypeScript AST diff engine implementation, surgical splicing algorithms, and automated test suites.

## Review Format
html

## Notes and Open Questions
Initialized cleanly in `C:\Users\ghanashyam\.gemini\antigravity\scratch\scopeguard`. Target deadline: October 26, 2026.
